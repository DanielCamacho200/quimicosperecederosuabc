<?php
function conectar(){
    /*$host="mysql";
    $user="root";
    $pass="root";
    $bd="clinicaComunitarias";*/
    $host="sql310.infinityfree.com";
    $user="if0_34357752";
    $pass="bQsUdCj7w5nWff";
    $bd="if0_34357752_clinicacomunitarias";

    $con = mysqli_connect($host, $user, $pass, $bd) or die("Unable to Connect to '$host'");
    return $con;
}
?>
