<?php session_start(); session_destroy(); Header("Location: ../vistas/iniciarsesion.php");?>
